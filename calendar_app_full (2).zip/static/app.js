let currentDate = new Date(2026, 4, 1);
let events = [];
let selectedColor = 'red';

document.addEventListener('DOMContentLoaded', () => {
    initMonthSel();
    addSamples();
    renderDays();
    renderRem();
    setupColors();
    document.getElementById('ev-date').value = '2026-05-16';
});

function initMonthSel() {
    const s = document.getElementById('month-sel');
    const m = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
    s.innerHTML = '';
    m.forEach((n, i) => {
        const o = document.createElement('option');
        o.value = i; o.textContent = `${n} ${currentDate.getFullYear()}`;
        if(i === currentDate.getMonth()) o.selected = true;
        s.appendChild(o);
    });
}

function addSamples() {
    const today = fmt(new Date());
    const tom = fmt(new Date(Date.now() + 86400000));
    events = [
        { id: 1, title: 'Презентация', date: today, time: '15:00', color: 'red', desc: 'Подготовить презентацию' },
        { id: 2, title: 'Ресторан', date: today, time: '16:00', color: 'blue', desc: 'Встреча' },
        { id: 3, title: 'Кино', date: tom, time: '12:50', color: 'green', desc: 'Премьера' },
        { id: 4, title: 'Театр', date: tom, time: '17:30', color: 'orange', desc: 'Спектакль' },
        { id: 5, title: 'Отправить письмо', date: today, time: '17:00', color: 'pink', desc: 'Важное письмо' }
    ];
}

function setupColors() {
    document.querySelectorAll('.dot').forEach(d => {
        d.onclick = () => {
            document.querySelectorAll('.dot').forEach(x => x.classList.remove('selected'));
            d.classList.add('selected');
            selectedColor = d.dataset.color;
        };
    });
}

function showScreen(n) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('screen-' + n).classList.add('active');
    document.querySelectorAll('.sidebar-item').forEach((i, idx) => {
        i.classList.remove('active');
        if(['calendar','event','recurrence','reminders'][idx] === n) i.classList.add('active');
    });
    if(n === 'reminders') renderRem();
    if(n === 'calendar') renderCurrentView();
}

function changeMonth(d) {
    currentDate.setMonth(currentDate.getMonth() + d);
    initMonthSel();
    renderCurrentView();
}

function changeMonthBySelect() {
    currentDate.setMonth(parseInt(document.getElementById('month-sel').value));
    renderCurrentView();
}

function goToday() {
    currentDate = new Date();
    initMonthSel();
    renderCurrentView();
}

function switchView(v) {
    document.querySelectorAll('.btn-pill').forEach(b => b.classList.remove('active'));
    document.getElementById('btn-' + v).classList.add('active');

    document.getElementById('view-month').style.display = v === 'month' ? 'block' : 'none';
    document.getElementById('view-week').style.display = v === 'week' ? 'block' : 'none';
    document.getElementById('view-day').style.display = v === 'day' ? 'block' : 'none';

    if(v === 'week') renderWeek();
    if(v === 'day') renderDay();
}

function renderCurrentView() {
    const active = document.querySelector('.btn-pill.active');
    if(!active) return;
    const view = active.id.replace('btn-', '');
    if(view === 'month') renderDays();
    else if(view === 'week') renderWeek();
    else if(view === 'day') renderDay();
}

function renderDays() {
    const g = document.getElementById('days');
    g.innerHTML = '';
    const y = currentDate.getFullYear(), m = currentDate.getMonth();
    const fd = new Date(y, m, 1).getDay();
    const dim = new Date(y, m + 1, 0).getDate();
    const dip = new Date(y, m, 0).getDate();
    const off = fd === 0 ? 6 : fd - 1;
    const tStr = fmt(new Date());

    for(let i = off - 1; i >= 0; i--) g.appendChild(mkDay(dip - i, false));
    for(let d = 1; d <= dim; d++) {
        const ds = `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
        const isT = ds === tStr;
        const evs = events.filter(e => e.date === ds);
        g.appendChild(mkDay(d, true, isT, ds, evs));
    }
    const rem = 42 - (off + dim);
    for(let i = 1; i <= rem; i++) g.appendChild(mkDay(i, false));
}

function mkDay(d, cur, today=false, ds='', evs=[]) {
    const c = document.createElement('div');
    c.className = 'day' + (!cur ? ' other' : '') + (today ? ' today' : '');
    c.textContent = d;

    if(cur && evs.length) {
        const mk = document.createElement('div');
        mk.className = 'day-marks';
        evs.slice(0, 3).forEach(e => {
            const dot = document.createElement('div');
            dot.className = 'mark';
            dot.style.background = getColor(e.color);
            mk.appendChild(dot);
        });
        c.appendChild(mk);
    }

    if(cur) {
        c.onclick = () => {
            document.querySelectorAll('.day').forEach(x => x.classList.remove('selected'));
            c.classList.add('selected');
            document.getElementById('ev-date').value = ds;
            showScreen('event');
        };
    }
    return c;
}

function renderWeek() {
    const hdr = document.getElementById('week-header');
    const body = document.getElementById('week-body');
    hdr.innerHTML = '';
    body.innerHTML = '';

    const start = getWeekStart(currentDate);
    const days = ['пн','вт','ср','чт','пт','сб','вс'];
    const todayStr = fmt(new Date());

    // Header
    for(let i=0; i<7; i++) {
        const d = new Date(start);
        d.setDate(d.getDate() + i);
        const isToday = fmt(d) === todayStr;
        hdr.innerHTML += `<div class="day-col-header ${isToday?'today':''}">${days[i]}<br>${d.getDate()}</div>`;
    }

    // Time slots
    for(let h=0; h<24; h++) {
        const time = `${String(h).padStart(2,'0')}:00`;
        body.innerHTML += `<div class="time-label">${time}</div>`;
        for(let i=0; i<7; i++) {
            const d = new Date(start);
            d.setDate(d.getDate() + i);
            const ds = fmt(d);
            const cellEvs = events.filter(e => e.date === ds && e.time && e.time.startsWith(time));
            const cell = document.createElement('div');
            cell.className = 'week-cell';
            cellEvs.forEach(e => {
                cell.innerHTML += `<div class="event-block" style="background:${getColor(e.color)}">${e.title}<br><small>${e.time}</small></div>`;
            });
            body.appendChild(cell);
        }
    }
}

function renderDay() {
    const hdr = document.getElementById('day-header');
    const body = document.getElementById('day-body');
    hdr.innerHTML = '';
    body.innerHTML = '';

    const ds = fmt(currentDate);
    const dayName = currentDate.toLocaleDateString('ru-RU', {weekday:'long', day:'numeric', month:'long'});
    hdr.innerHTML = `<h3>${dayName.charAt(0).toUpperCase() + dayName.slice(1)}</h3>`;

    const dayEvs = events.filter(e => e.date === ds);

    for(let h=0; h<24; h++) {
        const time = `${String(h).padStart(2,'0')}:00`;
        const slotEvs = dayEvs.filter(e => e.time && e.time.startsWith(time));
        body.innerHTML += `<div class="day-slot"><div class="slot-time">${time}</div><div class="slot-content">${slotEvs.map(e => `<div class="event-block" style="background:${getColor(e.color)}">${e.title}<br><small>${e.desc||''}</small></div>`).join('')}</div></div>`;
    }
}

function getWeekStart(date) {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.setDate(diff));
}

function getColor(c) {
    return {red:'#FF4136',yellow:'#FFDC00',green:'#2ECC40',cyan:'#7FDBFF',blue:'#0074D9',pink:'#FF66CC',orange:'#FF851B'}[c] || '#FF66CC';
}

function saveEvent() {
    const t = document.getElementById('ev-title').value.trim();
    const d = document.getElementById('ev-date').value;
    if(!t || !d) return alert('Заполните название и дату!');

    events.push({
        id: Date.now(),
        title: t,
        date: d,
        time: document.getElementById('ev-time-start').value,
        color: selectedColor,
        desc: document.getElementById('ev-desc').value
    });

    document.getElementById('ev-title').value = '';
    document.getElementById('ev-desc').value = '';
    renderCurrentView();
    showScreen('calendar');
}

function renderRem(f='all') {
    const c = document.getElementById('rem-list');
    c.innerHTML = '';
    const today = fmt(new Date());
    const tom = fmt(new Date(Date.now() + 86400000));

    let list = f === 'up' ? events.filter(e => e.date >= today) : f === 'past' ? events.filter(e => e.date < today) : events;
    const tEvs = list.filter(e => e.date === today);
    const tomEvs = list.filter(e => e.date === tom);
    const fut = list.filter(e => e.date > tom);

    if(tEvs.length) c.appendChild(sec('Сегодня', tEvs));
    if(tomEvs.length) c.appendChild(sec('Завтра', tomEvs));
    if(fut.length) c.appendChild(sec('Ближайшие', fut));
    if(!list.length) c.innerHTML = '<div style="text-align:center;padding:30px;color:#999">Нет напоминаний</div>';
}

function sec(title, evs) {
    const s = document.createElement('div');
    s.className = 'rem-section';
    s.innerHTML = `<h3>${title}</h3>`;
    evs.forEach(e => {
        const dt = new Date(e.date);
        const dn = dt.toLocaleDateString('ru-RU', {weekday:'long'});
        const ds = dt.toLocaleDateString('ru-RU', {day:'numeric',month:'long'});
        s.innerHTML += `<div class="rem-item">
            <div class="rem-dot" style="background:${getColor(e.color)}"></div>
            <div class="rem-info">
                <div class="rem-title">${e.title}</div>
                <div class="rem-time">${e.time}</div>
            </div>
            <div class="rem-meta">
                <span>🔔 Напоминание каждые 30 минут</span>
                <span class="rem-dots" onclick="delEvent(${e.id})">⋮</span>
            </div>
        </div>`;
    });
    return s;
}

function filterRem(f, btn) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    renderRem(f);
}

function delEvent(id) {
    if(confirm('Удалить?')) {
        events = events.filter(e => e.id !== id);
        renderCurrentView();
        renderRem();
    }
}

function updRecText() {
    const m = {day:'день', week:'неделю', month:'месяц'};
    document.getElementById('rec-unit').textContent = m[document.getElementById('rec-type').value];
}

function togEnd() {
    document.getElementById('end-opts').style.display = document.getElementById('no-end').checked ? 'none' : 'block';
}

function fmt(d) { return d.toISOString().split('T')[0]; }

function openSearch() { const q = prompt('🔍 Поиск:'); if(q) { const f = events.filter(e => e.title.toLowerCase().includes(q.toLowerCase())); alert(f.length ? `Найдено ${f.length}` : 'Не найдено'); } }
function openNotifications() { const t = fmt(new Date()); const evs = events.filter(e => e.date === t); alert(`🔔 Сегодня: ${evs.length} событий`); }
function openSettings() { alert(`⚙️ Настройки\nСобытий: ${events.length}`); }
function toggleFilters() { alert('☰ Фильтры'); }